package org.gina.cs355demo.WebBudgetCalculatorREST.service;
import java.util.ArrayList;
import java.util.List;
import org.gina.cs355sp18.WebBudgetCalculatorV2.resource.BudgetCategory;
public class BudgetService {
	private static List<BudgetCategory> catList = new ArrayList<>();	
	public BudgetService(){
		BudgetCategory c1 = new BudgetCategory("income");
		BudgetCategory c2 = new BudgetCategory("bills");
		BudgetCategory c3 = new BudgetCategory("living");
		BudgetCategory c4 = new BudgetCategory("misc");
		catList.add(c1);
		catList.add(c2);
		catList.add(c3);
		catList.add(c4);	
	}	
	public List<BudgetCategory> getCategories(){
		return catList;
	}
	public List<BudgetCategory> addCategory(BudgetCategory newcategory){
		catList.add(newcategory);
		return catList;
	}
}

