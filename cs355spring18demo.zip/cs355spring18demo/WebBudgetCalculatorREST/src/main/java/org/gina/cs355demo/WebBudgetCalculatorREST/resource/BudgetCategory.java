package org.gina.cs355demo.WebBudgetCalculatorREST.resource;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class BudgetCategory {
	private String categoryName;
	private List<BudgetItem> itemsList = new ArrayList<BudgetItem>();

	public BudgetCategory() {

	}

	// Constructors
	public BudgetCategory(String categoryName) {
		super();
		this.categoryName = categoryName;
		this.itemsList = null;
	}

	// Getters - Setters
	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public List<BudgetItem> getItemsList() {
		return itemsList;
	}

	public void setItemsList(List<BudgetItem> itemsList) {
		this.itemsList = itemsList;
	}
	

}

