package org.gina.cs355demo.WebBudgetCalculatorREST.resource;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class BudgetItem {
	private String category;
	private Double item;

	// Constructors
	public BudgetItem() {

	}

	public BudgetItem(String label, Double value) {
		super();
		this.category = label;
		this.item = value;
	}

	// Getters - Setters
	public String getLabel() {
		return category;
	}

	public void setLabel(String label) {
		this.category = label;
	}

	public Double getValue() {
		return item;
	}

	public void setValue(Double value) {
		this.item = value;
	}

}
