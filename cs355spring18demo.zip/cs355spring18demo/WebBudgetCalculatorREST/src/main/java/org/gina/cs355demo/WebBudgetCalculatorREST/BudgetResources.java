//paste to BudgetResources class
//code from Fig. 19

package org.gina.cs355demo.WebBudgetCalculatorREST;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import org.gina.cs355demo.WebBudgetCalculatorREST.service.BudgetService;
import org.gina.cs355demo.WebBudgetCalculatorREST.resource.BudgetCategory;

@Path("/categories")
public class BudgetResources {
	/*
 	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String getCategories(){
 		return "Category List: income, bills, living, misc";
	} 	
 	*/
	BudgetService budgSrv = new BudgetService();
 	@GET
	@Produces(MediaType.APPLICATION_XML)
	public List<BudgetCategory> getCategories(){
		return budgSrv.getCategories();
	} 
 	@GET
 	@Path("/{categoryid}")
 	@Produces(MediaType.APPLICATION_XML)
 	public BudgetCategory getCategory(@PathParam("categoryid") int catindex){
 		return budgSrv.getCategories().get(catindex);
 	} 		
 	
	@POST
 	@Produces(MediaType.APPLICATION_XML)
 	@Consumes(MediaType.APPLICATION_XML) 
 	public List<BudgetCategory> addCategory(BudgetCategory newCategory){
 		return budgSrv.addCategory(newCategory);
 	}
}