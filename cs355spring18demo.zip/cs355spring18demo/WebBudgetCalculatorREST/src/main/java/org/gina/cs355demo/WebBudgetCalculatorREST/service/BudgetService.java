package org.gina.cs355demo.WebBudgetCalculatorREST.service;
import java.util.ArrayList;
import java.util.List;
import org.gina.cs355demo.WebBudgetCalculatorREST.resource.BudgetCategory;
import org.gina.cs355demo.WebBudgetCalculatorREST.resource.BudgetItem;
public class BudgetService {
	private static List<BudgetCategory> catList = new ArrayList<>();	
	public BudgetService(){
		BudgetCategory c1 = new BudgetCategory("income");
		BudgetCategory c2 = new BudgetCategory("bills");
		BudgetCategory c3 = new BudgetCategory("living");
		BudgetCategory c4 = new BudgetCategory("misc");
		catList.add(c1);
		catList.add(c2);
		catList.add(c3);
		catList.add(c4);	
	}	
	public List<BudgetCategory> getCategories(){
		return catList;
	}
	public List<BudgetCategory> addCategory(BudgetCategory newcategory){
		catList.add(newcategory);
		return catList;
	}
	public List<BudgetCategory> deleteItem(int catindex, int itemindex) {
		catList.get(catindex).getItemsList().remove(itemindex);
		return catList;
	}
	
	public BudgetItem getItem(int catindex, int itemindex) {
		BudgetItem item = new BudgetItem();
		item = catList.get(catindex).getItemsList().get(itemindex);
		return item;
	}
	
	public List<BudgetItem> addItem(int catindex, BudgetItem newItem) {
		catList.get(catindex).getItemsList().add(newItem);
		return catList.get(catindex).getItemsList();
	}
}

