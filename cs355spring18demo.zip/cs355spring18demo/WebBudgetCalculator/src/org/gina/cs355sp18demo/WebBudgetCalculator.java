package org.gina.cs355sp18demo;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService 
public class WebBudgetCalculator {
	private ArrayList<String> categories = new ArrayList<>(Arrays.asList("income", "bills", "living", "misc"));
	private ArrayList<ArrayList<Double> > categoryItems = new ArrayList<>(Arrays.asList(new ArrayList<>()));
	
	public List<String> getCategories() {
		return categories;
	}
	
	@WebMethod
	public List<Double> getCategoryList(String category) {		

		// find category
		int index = findIndex(category);
		
		// if index was not found
		if (index == -1) {
			return new ArrayList<Double>();
		}
		
		// return
		return categoryItems.get(index);
	}
	
	@WebMethod
	public List<Double> addItem(String category, double item) {
		
		// find category
		int index = findIndex(category);
		
		// if index was not found
		if (index == -1) {
			return new ArrayList<Double>();
		}
		
		// add item to list at index
		categoryItems.get(index).add(new Double(item));
		
		// return
		return categoryItems.get(index);
	}
	
	@WebMethod
	public List<Double> deleteItem(String category, int index) {
		
		// find category
		int myIndex = findIndex(category);
		if (myIndex == -1) {
			return new ArrayList<Double>();
		}
		
		if (index < categoryItems.get(myIndex).size()) {
			categoryItems.get(myIndex).remove(index);
		} else {
			return new ArrayList<Double>();
		}
		
		return categoryItems.get(myIndex);
	}
	
	@WebMethod
	public double balance() {
		Double incomeTotal = new Double(0);
		Double costsTotal = new Double(0);
		
		// get incomeTotal
		for (int i = 0; i < categoryItems.get(0).size(); i++) {
			incomeTotal = incomeTotal + categoryItems.get(0).get(i);
		}
		
		// get costsTotal
		for (int i = 1; i < categoryItems.size(); i++) {
			for (int j = 0; j < categoryItems.get(i).size(); j++) {
				costsTotal = costsTotal + categoryItems.get(i).get(j);
			}
		}
		
		double ret = incomeTotal - costsTotal;
		return ret;
	}
	
	private int findIndex(String category) {
		int index = -1;
		category = category.toLowerCase();
		
		for (int i = 0; i < categories.size(); i++) {
			String currentCategory = categories.get(i).toLowerCase();
			
			if (currentCategory.equals(category)) {
				index = i;
			}
		}
		
		return index;
	}

}
